export type IconProps = React.SVGProps<SVGSVGElement>;

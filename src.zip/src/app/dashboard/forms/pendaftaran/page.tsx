"use client";

import Breadcrumb from "@/components/Breadcrumbs/Breadcrumb";
import { ShowcaseSection } from "@/components/Layouts/showcase-section";
import React, { useEffect, useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function Page() {
  const [pendaftaran, setPendaftaran] = useState<any>({});
  const [dataFormulir, setDataFormulir] = useState<any>({});

  useEffect(() => {
    const pendaftaranId = localStorage.getItem("pendaftaranId");
    const token = localStorage.getItem("token");
    const getPendaftaran = async () => {
      try {
        const res = await fetch(
          `${process.env.NEXT_PUBLIC_PENDAFTARAN_SERVICE_URL}/api/pendaftaran/${pendaftaranId}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          },
        );

        const pendaftaran = await res.json();
        console.log(pendaftaran);
        if (res.ok) {
          setPendaftaran(pendaftaran);
          setDataFormulir(pendaftaran.data.dataFormulir);
        }
      } catch (error) {
        console.log(error);
      }
    };

    getPendaftaran();
  }, []);

  return (
    <>
      <Breadcrumb pageName="Pendaftaran" />
      <div className="md-12 grid grid-cols-1 gap-6 md:grid-cols-2 md:gap-12 mb-6 md:mb-12">
        <ShowcaseSection title="Informasi">
          <div className="flex gap-2 mb-2">
            <div className="font-bold text-slate-800">Nomor Pendaftaran</div>
            <div>:</div>
            <div>{pendaftaran?.data?.nomorPendaftaran}</div>
          </div>
          <div className="flex gap-2 mb-2">
            <div className="font-bold text-slate-800">Gelombang Id</div>
            <div>:</div>
            <div>{pendaftaran?.data?.gelombangId}</div>
          </div>
          <div className="flex gap-2 mb-2">
            <div className="font-bold text-slate-800">Status Pendaftaran</div>
            <div>:</div>
            <div>{pendaftaran?.data?.status}</div>
          </div>
          <div className="flex gap-2 mb-2">
            <div className="font-bold text-slate-800">Catatan Admin</div>
            <div>:</div>
            <div>{pendaftaran?.data?.catatanAdmin}</div>
          </div>
        </ShowcaseSection>
      </div>
      <ShowcaseSection title="Data Formulir">
        {dataFormulir && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4 md:grid-cols-2">
              <p className="font-semibold">Nama Lengkap:</p>
              <p>{dataFormulir.nama}</p>

              <p className="font-semibold">Tempat Lahir:</p>
              <p>{dataFormulir.tempat_lahir}</p>

              <p className="font-semibold">Tanggal Lahir:</p>
              <p>{dataFormulir.tanggal_lahir}</p>

              <p className="font-semibold">Jenis Kelamin:</p>
              <p>{dataFormulir.jenis_kelamin}</p>

              <p className="font-semibold">Email Aktif:</p>
              <p>{dataFormulir.email_aktif}</p>

              <p className="font-semibold">No HP:</p>
              <p>{dataFormulir.no_tlp}</p>

              <p className="font-semibold">Agama:</p>
              <p>{dataFormulir.agama}</p>

              <p className="font-semibold">No KTP:</p>
              <p>{dataFormulir.no_ktp}</p>

              <p className="font-semibold">No KK:</p>
              <p>{dataFormulir.no_kk}</p>

              <p className="font-semibold">Alamat:</p>
              <p>{dataFormulir.alamat}</p>

              <p className="font-semibold">Desa / Kelurahan:</p>
              <p>{dataFormulir.desa_kelurahan}</p>

              <p className="font-semibold">Kecamatan:</p>
              <p>{dataFormulir.kecamatan}</p>

              <p className="font-semibold">Kabupaten / Kota:</p>
              <p>{dataFormulir.kota_kabupaten}</p>

              <p className="font-semibold">Nama Ayah Kandung:</p>
              <p>{dataFormulir.nama_ayah_kandung}</p>

              <p className="font-semibold">Nama Ibu Kandung:</p>
              <p>{dataFormulir.nama_ibu_kandung}</p>

              <p className="font-semibold">No HP Ortu:</p>
              <p>{dataFormulir.no_tlp_ortu}</p>

              <p className="font-semibold">Asal Sekolah:</p>
              <p>{dataFormulir.nama_asal_sekolah}</p>

              <p className="font-semibold">Tahun Lulus:</p>
              <p>{dataFormulir.tahun_lulus_sma}</p>

              <p className="font-semibold">NISN:</p>
              <p>{dataFormulir.nisn}</p>

              <p className="font-semibold">NPSN:</p>
              <p>{dataFormulir.npsn}</p>

              <p className="font-semibold">Nomor Pendaftaran KIPK:</p>
              <p>{dataFormulir.no_pendaftaran_kipk}</p>

              <p className="font-semibold">Prodi:</p>
              <p>{dataFormulir.prodi}</p>

              <p className="font-semibold">Sistem Kuliah:</p>
              <p>{dataFormulir.sistem_kuliah}</p>

              <p className="font-semibold">Rencana Tempat Tinggal:</p>
              <p>{dataFormulir.rencana_tinggal}</p>

              <p className="font-semibold">Alat Transportasi:</p>
              <p>{dataFormulir.alat_transportasi}</p>

              <p className="font-semibold">Referal:</p>
              <p>{dataFormulir.pemberi_rekomendasi}</p>

              <p className="font-semibold">No HP Referal:</p>
              <p>{dataFormulir.no_hp_pemberi_rekomendasi}</p>

              <p className="font-semibold">Asal Info STTC:</p>
              <p>{dataFormulir.asal_info_sttc}</p>

              <p className="font-semibold">Mengajukan Beasiswa:</p>
              <p>{dataFormulir.daftar_beasiswa}</p>
            </div>
          </div>
        )}
      </ShowcaseSection>
    </>
  );
}
